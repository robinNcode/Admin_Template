	
	// scroll

   $(document).ready(function() {
  
    $("#boxscroll").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true}); 
    $("#boxscrol2").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true});
    
  });





    
   
